# AI DevFest Tender Package Builder

Frontend-only React/Vite implementation of the AI DevFest Tender Package Builder challenge.

## Main requirements covered
- Load `requirements.json`
- Upload up to 30 PDFs / 50 MB total
- Reject non-PDF files
- Count PDF pages in-browser
- Detect damaged/password-protected PDFs with a clear error
- SHA-256 exact duplicate detection
- One-file-to-one-requirement matching
- Auto-match based on filenames
- Expiry-date entry and validation against submission deadline
- Required/optional status rules
- Generate button blocked by any blocking status
- English/Bangla interface
- Correct document ordering
- English cover page
- Optional document index page
- `Tender ID | Page X of Y` footer on every page
- Download `<tender_id>_Package.pdf`
- CSV checklist export
- Project metadata save/open workflow
- Browser-only document processing

## Run

```bash
npm install
npm run dev
```

Open the local Vite URL in the latest Google Chrome.

## Build

```bash
npm run build
```

## Competition notes

The project intentionally does not upload tender documents to any backend. PDF bytes are processed locally in the browser.

The Save Project export restores tender/checklist metadata, but browsers cannot serialize the original uploaded `File` objects into a portable JSON project. After reopening a project, re-upload the PDFs before generating the package.

The PNG signature/seal input is included in the UI as a bonus-workflow placeholder. Page placement requires a page-selection/editor layer and should be completed only if the core tasks are already stable.
