# Tender Package Builder

Frontend-only implementation for the AI DevFest Tender Package Builder challenge.

## Core requirements covered

- Load and validate `requirements.json`
- Display tender details and requirements sorted by `order`
- Upload up to 30 PDF files and 50 MB total
- Reject non-PDF files
- Count PDF pages in-browser
- Detect damaged/password-protected PDFs without crashing
- Match one file to at most one requirement and one requirement to at most one file
- SHA-256 exact-content duplicate detection
- Prevent duplicate-content files from being assigned to different requirements
- Expiry-date entry and validation against `submission_deadline`
- Required status: Missing / Expiry date needed / Expired / Not provided / OK
- Disable generation while any blocking status exists
- English/Bangla UI and document names from `title_en` / `title_bn`
- Generate `<tender_id>_Package.pdf`
- English cover page
- Documents in required order, preserving all source pages
- Optional index page
- `tender_id | Page X of Y` footer on every final page
- CSV checklist export
- Project settings save/open (PDFs must be re-uploaded after reopening)
- Optional PNG signature/seal placement on selected final-package pages

## Run

```bash
npm install
npm run dev
```

For production build:

```bash
npm run build
npm run preview
```

Use the latest Google Chrome. All PDF processing is performed in the browser. No tender document is sent to a backend.

## Sample requirements

`public/requirements.example.json` is only an example format. In the contest, use the provided `requirements.json` from the sample pack.

## Deployment

The app is a static Vite site. It can be deployed to any static HTTPS host that serves the Vite build output. No backend is required.
